use testopia;

CREATE TABLE Users(user_id INT IDENTITY(1,1) PRIMARY KEY,
name varchar(30),
dob date,
phone int,
email varchar(30),
username varchar(15),
password varchar(15));

CREATE TABLE Test(test_id INT IDENTITY(1,1) PRIMARY KEY,
user_id int,
name varchar(max),
duration time,
starttime time,
endtime time,
date date,
totalmarks int,
obtainedmarks int,
CONSTRAINT FK_User_Test FOREIGN KEY (user_id) REFERENCES Users(user_id));

CREATE TABLE Domain(domain_id tinyint IDENTITY(1,1) PRIMARY KEY,
domain varchar(max));

CREATE TABLE DifficultyLevel (difficulty_id tinyint IDENTITY(1,1) PRIMARY KEY,
difficultylevel varchar(max));

CREATE TABLE Options (option_id int IDENTITY(1,1) PRIMARY KEY,
options varchar(max));

CREATE TABLE Question(question_id int IDENTITY(1,1) PRIMARY KEY,
question varchar(max),
explanation date,
answer int,
difficultylevel tinyint,
domain tinyint,
CONSTRAINT FK_Answers FOREIGN KEY (answer) REFERENCES Options(option_id),
CONSTRAINT FK_Difficulty FOREIGN KEY (difficultylevel) REFERENCES DifficultyLevel(difficulty_id),
CONSTRAINT FK_Domain FOREIGN KEY (domain) REFERENCES Domain(domain_id));

CREATE TABLE QuestionSet(questionset_id int IDENTITY(1,1) PRIMARY KEY,
test_id int,
options_id int,
option_chosen int,
question_id int,
CONSTRAINT FK_Options FOREIGN KEY (options_id) REFERENCES Options(option_id),
CONSTRAINT FK_ChosenOption FOREIGN KEY (option_chosen) REFERENCES Options(option_id),
CONSTRAINT FK_Questions FOREIGN KEY (question_id) REFERENCES Question(question_id),
CONSTRAINT FK_Tests FOREIGN KEY (test_id) REFERENCES Test(test_id));

CREATE TABLE Questioncontribution(questioncontribution_id int IDENTITY(1,1) PRIMARY KEY,
creator_id int,
reviewer_id int,
question_id int,
CONSTRAINT FK_Creator FOREIGN KEY (creator_id) REFERENCES Users(user_id),
CONSTRAINT FK_Reviewer FOREIGN KEY (reviewer_id) REFERENCES Users(user_id),
CONSTRAINT FK_QuestionNo FOREIGN KEY (question_id) REFERENCES Question(question_id));

SELECT TABLE_NAME
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'BASE TABLE'

select * from Users;
select * from Test;
select * from Question;
select * from Options;
select * from QuestionSet;
select * from QuestionAnswer;
select * from Questioncontribution;
select * from Domain;
select * from DifficultyLevel;
select * from Stagingtable1; ORDER BY Questions;

--INSERT INTO Question(difficultylevel)
SELECT s.Questions,s.Explanation,d.difficulty_id,a.domain_id
,o.option_id
FROM stagingtable1 s join Difficultylevel d on s.level = d.difficultylevel
join domain a on s.Domain = a.domain
join options o on s.[Correct option] = o.options
ORDER BY s.Questions;


DELETE FROM StagingTable1
WHERE (Correct Option IS NULL OR Option 1 IS NULL OR Option2 IS NULL OR Option 3 IS NULL OR Option4 IS NULL);

CREATE TABLE QuestionAnswer(qa_id INT IDENTITY(1,1) PRIMARY KEY,
question_id int,
option_id int,
CONSTRAINT FK_qquestion FOREIGN KEY (question_id) REFERENCES Question(question_id),
CONSTRAINT FK_aanswer FOREIGN KEY (option_id) REFERENCES Options(option_id));

CREATE TABLE QuestionSet(questionset_id int IDENTITY(1,1) PRIMARY KEY,
test_id int,
qa_id int,
option_chosen int,
CONSTRAINT FK_Options FOREIGN KEY (qa_id) REFERENCES QuestionAnswer(qa_id),
CONSTRAINT FK_ChosenOption FOREIGN KEY (option_chosen) REFERENCES Options(option_id),
CONSTRAINT FK_Tests FOREIGN KEY (test_id) REFERENCES Test(test_id));

UPDATE StagingTable1
SET [Option 1] = LTRIM([Option 1])
WHERE [Option 1] LIKE ' %';

UPDATE StagingTable1
SET [Option2] = LTRIM([Option2])
WHERE [Option2] LIKE ' %';

UPDATE StagingTable1
SET [Option 3] = LTRIM([Option 3])
WHERE [Option 3] LIKE ' %';

UPDATE StagingTable1
SET [Correct option] = LTRIM([Correct option])
WHERE [Correct option] LIKE ' %';

INSERT INTO Options(options)
SELECT DISTINCT [Option4]
FROM StagingTable1;

alter table options
alter column options varchar(max);

DELETE FROM Options
WHERE Options IS NULL;

WITH CTE AS (
  SELECT Options, 
         ROW_NUMBER() OVER (PARTITION BY Options ORDER BY(SELECT 0)) AS RowNumber
  FROM Options
)
DELETE FROM CTE WHERE RowNumber > 1 OR Options IS NULL;

select * from options;

SELECT s.question_id
FROM StagingTable1 s join QuestionAnswer q on s.question_id = q.question_id
join s.answer = q.option_id
ORDER BY s.Question;


INSERT INTO QuestionAnswer(question_id,option_id)


WITH MyCTE AS (
select DISTINCT Questions,value,ROW_NUMBER() OVER (Partition BY Questions ORDER BY Questions) RN FROM StagingTable1
cross apply string_split([Option 1]+','+[Option2]+','+[Option 3]+','+[Option4],',')
)
SELECT * into #temp1 FROM MyCTE  WHERE RN < 5

select * from #temp

--INSERT INTO QuestionAnswer(question_id,option_id)
select * from question where question not in
(
SELECT distinct q.question FROM #temp p 
JOIN question q ON trim(Q.question) = trim(p.Questions)
JOIN Options o ON o.options = p.value);

EXEC sp_fkeys 'Questionset'

ALTER TABLE QuestionSet
DROP CONSTRAINT FK_Options;

SELECT
    obj.name AS 'ConstraintName',
    obj.type_desc AS 'ConstraintType',
    tab.name AS 'TableName'
FROM
    sys.objects AS obj
INNER JOIN
    sys.tables AS tab ON obj.parent_object_id = tab.object_id
WHERE
    obj.type = 'F'
    AND tab.name = 'Questionset'

ALTER TABLE Questionset
ADD question_id int;

ALTER TABLE Questionset
ADD CONSTRAINT FK_Questionid
FOREIGN KEY (question_id) 
REFERENCES Question(question_id);